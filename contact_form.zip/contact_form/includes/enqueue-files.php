<?php

// Enqueue Files
function contact_form_enqueue_scripts() {
  wp_enqueue_style( 'contact-form-main-css', plugin_dir_url( __DIR__ ) . 'assets/css/main.css'  );
  wp_enqueue_style( 'contact-form-grid-css', plugin_dir_url( __DIR__ ) . 'assets/css/grid.min.css'  );
  wp_enqueue_style( 'contact-form-intlTelInput', plugin_dir_url( __DIR__ ) . 'assets/css/intlTelInput.css'  );

  wp_enqueue_script( 'contact-form-jquery-js', plugin_dir_url( __DIR__ ) . 'assets/js/jquery.min.js', false);
  wp_enqueue_script( 'contact-form-nicescroll', plugin_dir_url( __DIR__ ) . 'assets/js/jquery.nicescroll.min.js', false);
  wp_enqueue_script( 'contact-form-main-js', plugin_dir_url( __DIR__ ) . 'assets/js/main.js', false);
  wp_enqueue_script( 'contact-form-validate', plugin_dir_url( __DIR__ ) . 'assets/js/validateFormContact.js', false);
  wp_enqueue_script( 'contact-form-masking', plugin_dir_url( __DIR__ ) . 'assets/js/mask.min.js', false);
  wp_enqueue_script( 'contact-form-intlTelInput', plugin_dir_url( __DIR__ ) . 'assets/js/intlTelInput.min.js', false);
  wp_enqueue_script( 'contact-form-utils', plugin_dir_url( __DIR__ ) . 'assets/js/utils.js', false);
}

add_action( 'wp_enqueue_scripts', 'contact_form_enqueue_scripts', 11);