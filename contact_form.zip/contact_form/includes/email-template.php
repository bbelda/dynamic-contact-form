<?php
// Email template sending
function replace_empty_with_NA_contact(&$text) {
  if($text == '' || $text == null) {
      $text = 'N/A';
  }
}
  
function contact_form() {
  array_walk_recursive($_POST,'replace_empty_with_NA_contact');
  $to_customer = $_POST['contact-email-address'] ;
  $to_internal = 'bbelda@cyzerg.com,bbelda.cyzerg@gmail.com';
  $subject = 'Sample Subject - Quote Summary';
  $headers = array();
  $headers[] = 'Content-Type: text/html; charset=UTF-8';
  $headers[] = 'From: Sample Subject <noreply@wordpress.net>';

  $response = array();

  $languages = get_locale();
  $heading = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <title>Customer Quoting</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>
    <body>
      <h2>Contact Information</h2>
      <table role="presentation" align="center" cellpadding="0" cellspacing="0" width="492" style="border-collapse: collapse;">
        <tr>
          <td>
            <p>Name: </p>
          </td>
          <td>
            <p>'.$_POST['contact-full-name'].'</p>
          </td>
        </tr>
        <tr>
          <td>
            <p>Company: </p>
          </td>
          <td>
            <p>'.$_POST['contact-company-name'].'</p>
          </td>
        </tr>
        <tr>
          <td>
            <p>Email: </p>
          </td>
          <td>
            <a href="mailto:'.$_POST['contact-email-address'].'">'.$_POST['contact-email-address'].'</a>
          </td>
        </tr>
        <tr>
          <td>
            <p>Phone Number: </p>
          </td>
          <td>
            <a href="tel:'.$_POST['english-dial-code'].' '.$_POST['contact-phone-number'].'">'.$_POST['english-dial-code'].' '.$_POST['contact-phone-number'].'</a>
          </td>
        </tr>
        <tr>
          <td colspan="2">
            <p>Message: </p>
          </td>
        </tr>
        <tr>
          <td colspan="2">
            <p>'.nl2br($_POST['contact-message']).'</p>
          </td>
        </tr>
      </table>
    </body>
  </html>
  ';

  $customer_template = $heading;
  $company_template = $heading;

  if(wp_mail( $to_customer, $subject, $customer_template, $headers) && wp_mail( $to_internal, $subject, $company_template, $headers)) {
    // $response['status'] = 'success';
    // $response['language'] = $languages;
    $_POST['status'] = 'success';
    // $_POST['language'] = $languages;
  } else {
    // $response['status'] = 'error'; 
    // $response['language'] = $languages;
    $_POST['status'] = 'error';
    // $_POST['language'] = $languages;
  }
  echo json_encode($_POST); exit;

}

add_action( 'wp_ajax_nopriv_contact-form', 'contact_form' );
add_action( 'wp_ajax_contact-form', 'contact_form' );