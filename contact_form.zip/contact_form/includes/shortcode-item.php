<?php 

// Creating shortcode name
function form_shorcode() {
	ob_start();
	// quoting_form();
	html_contact_form_code();

	return ob_get_clean();
}

add_shortcode( 'contact_form', 'form_shorcode' );