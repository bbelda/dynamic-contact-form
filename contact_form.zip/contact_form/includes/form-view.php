<?php 

function html_contact_form_code() {
?>
  <div class="contact-form">
    <div class="row">
      <div class="col-md-12">
        <div class="contact-heading">
          <h2>Contact Form</h2>
        </div>
      </div>
    </div>
    <form class="form" novalidate autocomplete="off" action="/wp-admin/admin-ajax.php" method="POST">
      <div class="form-container">
      <input type="hidden" name="action" value="contact-form">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <input type="text" name="contact-full-name" placeholder="Full Name*" required class="letter-format">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <input type="text"  name="contact-company-name" placeholder="Company Name">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <input type="email" name="contact-email-address" placeholder="Email Address" required>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <input type="tel" name="contact-phone-number" id="phone-number" required>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
              <div class="form-group">
              <textarea name="contact-message" id="" cols="30" rows="10" placeholder="Message"></textarea>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
              <div class="form-group">
              <button type="submit" class="btn btn-primary">Send</button>
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>

<?php
}
?>