<?php
/*
Plugin Name: Contact Form w/ Worldwide Phone Number Selection
Description: A shortcode for the contact form with a phone numbers of different countries. The shortcode is [contact_form].
Version: 1.0
Author: Bernard Belda Jr.
*/


require __DIR__ ."/includes/enqueue-files.php";

require __DIR__ ."/includes/form-view.php";

require __DIR__ ."/includes/email-template.php";

require __DIR__ ."/includes/shortcode-item.php";

?>