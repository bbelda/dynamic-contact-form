(function ($) {
  $(document).ready(function () {
    countryNumberField();
    contactForm();
    maskingField();
    inputDynamic();
  });

  function countryNumberField() {
    var input = $("#phone-number");
    if (input.length > 0) {
      var placeholder = input.attr("placeholder");
      var iti = window.intlTelInput(input[0], {
        // nationalMode: true,
        preferredCountries: "",
        separateDialCode: true,
        initialCountry: "us",
        autoHideDialCode: false,
        geoIpLookup: "auto",
        customPlaceholder: function (
          selectedCountryPlaceholder,
          selectedCountryData
        ) {
          // console.log(selectedCountryData);
          if (selectedCountryData.name == "United States") {
            placeholder = "(000) 000-0000";
            return placeholder;
          } else if (selectedCountryData.name == "Philippines") {
            placeholder = "000 000 0000";
            return placeholder;
          } else {
            return selectedCountryPlaceholder;
          }
        },
      });

      // $(".iti__selected-flag .iti__selected-dial-code").insertAfter(
      //   $(".iti__selected-flag")
      // );

      // console.log(placeholder);
      input.mask(placeholder.replace(/[0-9]/g, "Z"), {
        translation: {
          Z: {
            pattern: /[0-9]/g,
          },
        },
      });

      var height_dropdown = $(".iti .iti__flag-container");
      height_dropdown.height(input.outerHeight());

      input.on("input paste", function () {
        // if ($(this).val() == "") {
        var country = iti.getSelectedCountryData();
        // console.log(country);
        if (country.iso2 == "us") {
          placeholder = "(000) 000-0000";
        } else if (country.iso2 == "ph") {
          placeholder = "000 000 0000";
        } else {
          placeholder = $(this).attr("placeholder");
        }
        $(this).attr("placeholder", placeholder);
        input.attr("placeholder", placeholder.replace(/[0-9]/g, "0"));
        // }
      });

      input.on("countrychange", function (event, countryData) {
        var placeholder = input.attr("placeholder");
        input.attr("placeholder", placeholder.replace(/[0-9]/g, "0"));
        input.val("");
        input
          .mask("0#")
          .unmask()
          .mask(placeholder.replace(/[0-9]/g, "Z"), {
            translation: {
              Z: {
                pattern: /[0-9]/g,
              },
            },
          });
        $("#phone-number").parent().find(".error").remove();
        $("#phone-number").removeClass("error-field");
      });

      $(".contact-form .iti .iti__country-list .iti__country").each(
        function () {
          var text = $(this).find(".iti__country-name");
          var code_number = $(this).find(".iti__dial-code");
          var text_code = $(this).attr("data-country-code");

          if (text_code == "cg") {
            text.html("Congo Republic");
            code_number.appendTo(text);
          } else if (text_code == "cd") {
            text.html("Congo DRC");
            code_number.appendTo(text);
          } else if (text_code == "us") {
            text.html("United States of America");
            code_number.appendTo(text);
          } else {
            text.html(text.html().replace(/ *\([^)]*\) */g, ""));
            code_number.appendTo(text);
          }
        }
      );
      $(".contact-form .iti .iti__country-list").length > 0 &&
        $(".contact-form .iti .iti__country-list").niceScroll({
          cursorwidth: "4px",
          cursorcolor: "rgba(192, 193, 200, 0.8)",
          cursorborder: "0px solid #c0c1c8",
          cursorborderradius: "5px",
          cursorminheight: 63,
          railpadding: { right: 2 },
          autohidemode: false,
          cursordragspeed: 0.6,
          scrollspeed: 90,
        });
    }
  }

  function contactForm() {
    $(".contact-form form button").on("click", function (event) {
      event.preventDefault();
      var form = $(".contact-form form");
      var button = $(this);
      form.validate();
      if (form.valid()) {
        $.ajax({
          url: form.attr("action"),
          method: form.attr("method"),
          data:
            form.serialize() +
            "&english-dial-code=" +
            encodeURIComponent($(".iti__selected-dial-code").html()),
          dataType: "json",
          beforeSend: function (response) {
            button.addClass("sending");
            button.attr("disabled", "disabled");
          },
          always: function (response) {
            button.removeClass("sending");
            button.removeAttr("disabled");
          },
          success: function (response) {
            // if (response.status == "success") {
            //   form.fadeOut(300, function () {
            //     form.next().fadeIn(300);
            //   });
            // }
            // if(response.status == 'success') {
            //     form.fadeOut(300, function() {
            //         $('.contact-thankyou-container').fadeIn(300);
            //     })
            // } else if(response.status == 'error') {
            //     $('.contact-thankyou-container').fadeOut(300, function() {
            //         form.fadeIn(300);
            //     })
            // }
            console.log(response);
          },
          error: function (response) {
            console.log(response);
          },
        });
        // console.log("valid");
      }
    });
  }

  function inputDynamic() {
    $(".contact-form form input").on("input paste", function () {
      if ($(this).parent().valid()) {
        $(this).parent().find(".error").remove();
      } else {
        $(this).parent().validate();
      }
    });
  }

  function maskingField() {
    $(".letter-format").mask("Z", {
      translation: {
        Z: {
          pattern: /[a-zA-Z ]/,
          recursive: true,
        },
      },
    });
  }
})(jQuery);
